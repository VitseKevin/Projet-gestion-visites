<!Doctype html>
<html>
<head>
    <title>Mon Site</title>
    <link rel="stylesheet" href="<?php echo RACINE_SITE; ?>inc/css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
            
</head>
<body>
<header>
    <div class="conteneur">

        <nav>
            <a href="<?php echo RACINE_SITE; ?>./vue/acceuil.php">Acceuil</a>
        </nav>
    </div>
</header>
<section>
    <div class="conteneur">






