<?php

require_once("../inc/init.inc.php");
require_once("../model/visiteur.php");


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les valeurs des champs de mot de passe
    $mdp = $_POST["mdp"];
    $confirme_mdp = $_POST["mdp1"];

    // Vérifier si les mots de passe correspondent
    if ($mdp == $confirme_mdp) {


        $mdp->updatemdp($pdo,$nouveauVisiteur);

         // Rediriger après la modification des données
    header("Location: ../vue/connexion.php");
    exit();


    }
    else {
        // Les mots de passe ne correspondent pas, rediriger ou afficher un message d'erreur
        header("Location: ../modif_mdp1.php");
        exit();
    }

}
?>
